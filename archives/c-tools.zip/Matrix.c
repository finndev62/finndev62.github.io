#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/utsname.h>
#include <time.h>

// Renk ve efektler için ANSI kodları
#define GREEN "\x1b[32m"
#define BOLD_GREEN "\x1b[1;32m"
#define RED_BLINK "\x1b[5;31m"
#define RESET "\x1b[0m"
#define CLEAR_SCREEN "\x1b[2J\x1b[H"

void print_system_info() {
    struct utsname buffer;
    if (uname(&buffer) != 0) {
        perror("uname");
        return;
    }

    // Sistem bilgilerini havalı bir şekilde yazdıralım
    printf("\n" BOLD_GREEN "--- SYSTEM TARGET DETECTED ---" RESET "\n");
    printf(GREEN "OS Name:    %s" RESET "\n", buffer.sysname);
    printf(GREEN "Node Name:  %s" RESET "\n", buffer.nodename);
    printf(GREEN "Release:    %s" RESET "\n", buffer.release);
    printf(GREEN "Version:    %s" RESET "\n", buffer.version);
    printf(GREEN "Machine:    %s" RESET "\n", buffer.machine);
    printf(BOLD_GREEN "------------------------------" RESET "\n\n");
}

int main() {
    // Rastgele sayı üreticiyi başlat
    srand(time(NULL));

    // Ekranı temizle
    printf(CLEAR_SCREEN);
    
    // Önce sistem bilgilerini tespit edip döküyoruz
    print_system_info();
    sleep(2); // Bilgileri okumak için 2 saniye bekle

    printf(BOLD_GREEN "INITIALIZING MATRIX STREAM..." RESET "\n");
    sleep(1);

    int counter = 0;
    
    // Sonsuz döngü: 0 ve 1'ler akacak
    while (1) {
        // Rastgele 0 veya 1 yazdır (Yeşil renkte)
        printf(GREEN "%d " RESET, rand() % 2);
        
        // Standart çıktıyı zorla (hemen ekrana basılsın diye)
        fflush(stdout);

        // Arada bir (her 150 karakterde bir) alt satıra geç ve uyarıyı göster
        if (counter % 40 == 0 && counter > 0) {
            printf("\n");
        }

        if (counter % 200 == 0 && counter > 0) {
            // En altta yanıp sönen kırmızı "HACKING" uyarısı
            printf("\n" RED_BLINK ">>> DEVICE IS BEING HACKED... <<<" RESET "\n\n");
            usleep(500000); // Uyarı görünsün diye yarım saniye durakla
        }

        // Akış hızı kontrolü (mikrosaniye cinsinden, 20000 = 0.02 saniye)
        usleep(20000);
        counter++;
    }

    return 0;
}
